using TaskManagementApp.Models;
using TaskManagementApp.Services.Concrete;

namespace TaskManagementApp.Tests.Services.Tests
{
    [TestFixture]
    public class TaskServiceTests
    {
        private TaskService _taskService;

        [SetUp]
        public void SetUp()
        {
            _taskService = new TaskService();
        }

        //Add a new task
        [Test]
        public void AddTask_ShouldAddTaskSuccessfully()
        {
            var task = new TaskItem { Name = "New Task", Description = "Test", Deadline = DateTime.Now.AddDays(2) };
            _taskService.AddTask(task);

            var tasks = _taskService.GetAllTasks().ToList();
            Assert.That(tasks.Count, Is.EqualTo(1));
            Assert.That(tasks[0].Name, Is.EqualTo("New Task"));
        }

        //Get an existing task
        [Test]
        public void GetTask_ShouldReturnTask_WhenTaskExists()
        {
            var task = new TaskItem { Name = "New Task", Description = "Test", Deadline = DateTime.Now.AddDays(2) };
            _taskService.AddTask(task);

            var retrievedTask = _taskService.GetTask(1);

            Assert.IsNotNull(retrievedTask);
            Assert.That(retrievedTask.Name, Is.EqualTo("New Task"));
        }

        //Get a non-existent task
        [Test]
        public void GetTask_ShouldReturnNull_WhenTaskDoesNotExist()
        {
            var retrievedTask = _taskService.GetTask(99);

            Assert.IsNull(retrievedTask);
        }

        //Edit an existing task
        [Test]
        public void EditTask_ShouldEditTaskSuccessfully_WhenTaskExists()
        {
            var task = new TaskItem { Name = "Old Task", Description = "Test", Deadline = DateTime.Now.AddDays(2) };
            _taskService.AddTask(task);

            var updatedTask = new TaskItem { Name = "Updated Task", Description = "Updated Description", Deadline = DateTime.Now.AddDays(5) };
            var result = _taskService.EditTask(1, updatedTask);

            Assert.IsTrue(result);
            var editedTask = _taskService.GetTask(1);
            Assert.That(editedTask.Name, Is.EqualTo("Updated Task"));
        }

        //Edit a non-existent task
        [Test]
        public void EditTask_ShouldReturnFalse_WhenTaskDoesNotExist()
        {
            var updatedTask = new TaskItem { Name = "Updated Task", Description = "Updated Description", Deadline = DateTime.Now.AddDays(5) };
            var result = _taskService.EditTask(99, updatedTask);

            Assert.IsFalse(result);
        }

        //Delete an existing task
        [Test]
        public void DeleteTask_ShouldRemoveTask_WhenTaskExists()
        {
            var task = new TaskItem { Name = "Task to Delete", Description = "Test", Deadline = DateTime.Now.AddDays(2) };
            _taskService.AddTask(task);

            var result = _taskService.DeleteTask(1);
            Assert.IsTrue(result);
            Assert.IsNull(_taskService.GetTask(1));
        }

        //Delete a non-existent task
        [Test]
        public void DeleteTask_ShouldReturnFalse_WhenTaskDoesNotExist()
        {
            var result = _taskService.DeleteTask(99);
            Assert.IsFalse(result);
        }

        //Move task to a new column
        [Test]
        public void MoveTaskToColumn_ShouldMoveTaskSuccessfully_WhenTaskExists()
        {
            var task = new TaskItem { Name = "Task to Move", ColumnName = "ToDo" };
            _taskService.AddTask(task);

            var result = _taskService.MoveTaskToColumn(1, "In Progress");
            Assert.IsTrue(result);

            var movedTask = _taskService.GetTask(1);
            Assert.That(movedTask.ColumnName, Is.EqualTo("In Progress"));
        }

        //Move task to a new column when task does not exist
        [Test]
        public void MoveTaskToColumn_ShouldReturnFalse_WhenTaskDoesNotExist()
        {
            var result = _taskService.MoveTaskToColumn(99, "In Progress");
            Assert.IsFalse(result);
        }
    }
}
