﻿using Moq;
using TaskManagementApp.Controllers;
using TaskManagementApp.Models;
using TaskManagementApp.Services.Abstract;
using System.Net;
using System.Text.Json;

namespace TaskManagementApp.Tests.Controllers.Tests
{
    [TestFixture]
    public class TasksControllerTests
    {
        private Mock<ITaskService> _taskServiceMock;
        private TasksController _controller;

        [SetUp]
        public void Setup()
        {
            _taskServiceMock = new Mock<ITaskService>();
            _controller = new TasksController(_taskServiceMock.Object);
        }

        [Test]
        public void GetAllTasks_ShouldReturnOkWithTaskList()
        {
            // Arrange
            var tasks = new List<TaskItem> {
                new TaskItem { Id = 1, Name = "Task 1", Description = "Description 1" },
                new TaskItem { Id = 2, Name = "Task 2", Description = "Description 2" }
            };

            _taskServiceMock.Setup(x => x.GetAllTasks()).Returns(tasks);

            // Act
            var result = _controller.GetAllTasks();

            // Assert
            Assert.That(result.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            var serializedTasks = JsonSerializer.Serialize(tasks);
            Assert.That(result.Content.ReadAsStringAsync().Result, Is.EqualTo(serializedTasks));
        }

        [Test]
        public void AddTask_ShouldReturnBadRequestWhenTaskNameIsEmpty()
        {
            // Arrange
            var task = new TaskItem { Id = 1, Name = "", Description = "Description 1" };

            // Act
            var result = _controller.AddTask(task);

            // Assert
            Assert.That(result.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        }

        [Test]
        public void AddTask_ShouldReturnOkWhenTaskIsValid()
        {
            // Arrange
            var task = new TaskItem { Id = 1, Name = "Task 1", Description = "Description 1" };

            _taskServiceMock.Setup(x => x.AddTask(It.IsAny<TaskItem>()));

            // Act
            var result = _controller.AddTask(task);

            // Assert
            Assert.That(result.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            _taskServiceMock.Verify(x => x.AddTask(It.IsAny<TaskItem>()), Times.Once);
        }

        [Test]
        public void EditTask_ShouldReturnNotFoundWhenTaskDoesNotExist()
        {
            // Arrange
            var updatedTask = new TaskItem { Id = 1, Name = "Updated Task", Description = "Updated Description" };

            _taskServiceMock.Setup(x => x.GetTask(1)).Returns(() => { return null; });

            // Act
            var result = _controller.EditTask(1, updatedTask);

            // Assert
            Assert.That(result.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
        }

        [Test]
        public void EditTask_ShouldReturnOkWhenTaskIsUpdated()
        {
            // Arrange
            var updatedTask = new TaskItem { Id = 1, Name = "Updated Task", Description = "Updated Description" };
            var existingTask = new TaskItem { Id = 1, Name = "Task 1", Description = "Description 1" };

            _taskServiceMock.Setup(x => x.GetTask(1)).Returns(existingTask);
            _taskServiceMock.Setup(x => x.EditTask(1, updatedTask));

            // Act
            var result = _controller.EditTask(1, updatedTask);

            // Assert
            Assert.That(result.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            _taskServiceMock.Verify(x => x.EditTask(1, updatedTask), Times.Once);
        }

        [Test]
        public void DeleteTask_ShouldReturnNotFoundWhenTaskDoesNotExist()
        {
            // Arrange
            _taskServiceMock.Setup(x => x.GetTask(1)).Returns(() => { return null; });

            // Act
            var result = _controller.DeleteTask(1);

            // Assert
            Assert.That(result.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
        }

        [Test]
        public void DeleteTask_ShouldReturnOkWhenTaskIsDeleted()
        {
            // Arrange
            var task = new TaskItem { Id = 1, Name = "Task 1", Description = "Description 1" };

            _taskServiceMock.Setup(x => x.GetTask(1)).Returns(task);
            _taskServiceMock.Setup(x => x.DeleteTask(1));

            // Act
            var result = _controller.DeleteTask(1);

            // Assert
            Assert.That(result.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            _taskServiceMock.Verify(x => x.DeleteTask(1), Times.Once);
        }

        [Test]
        public void GetTask_ShouldReturnNotFoundWhenTaskDoesNotExist()
        {
            // Arrange
            _taskServiceMock.Setup(x => x.GetTask(1)).Returns(() => { return null; });

            // Act
            var result = _controller.GetTask(1);

            // Assert
            Assert.That(result.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
        }

        [Test]
        public void GetTask_ShouldReturnOkWithTaskDetails()
        {
            // Arrange
            var task = new TaskItem { Id = 1, Name = "Task 1", Description = "Description 1" };

            _taskServiceMock.Setup(x => x.GetTask(1)).Returns(task);

            // Act
            var result = _controller.GetTask(1);

            // Assert
            Assert.That(result.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(result.Content.ReadAsStringAsync().Result, Is.EqualTo($"Task Name: {task.Name}, Description: {task.Description}"));
        }

        [Test]
        public void MoveTaskToColumn_ShouldReturnNotFoundWhenTaskDoesNotExist()
        {
            // Arrange
            _taskServiceMock.Setup(x => x.GetTask(1)).Returns(()=> { return null; });

            // Act
            var result = _controller.MoveTaskToColumn(1, "In Progress");

            // Assert
            Assert.That(result.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
        }

        [Test]
        public void MoveTaskToColumn_ShouldReturnOkWhenTaskIsMoved()
        {
            // Arrange
            var task = new TaskItem { Id = 1, Name = "Task 1", Description = "Description 1" };

            _taskServiceMock.Setup(x => x.GetTask(1)).Returns(task);
            _taskServiceMock.Setup(x => x.MoveTaskToColumn(1, "In Progress"));

            // Act
            var result = _controller.MoveTaskToColumn(1, "In Progress");

            // Assert
            Assert.That(result.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            _taskServiceMock.Verify(x => x.MoveTaskToColumn(1, "In Progress"), Times.Once);
        }
    }
}
