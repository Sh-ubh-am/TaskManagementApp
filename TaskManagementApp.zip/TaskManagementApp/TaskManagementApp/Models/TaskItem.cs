namespace TaskManagementApp.Models
{
    public class TaskItem
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public DateTime Deadline { get; set; }
        public bool IsFavorited { get; set; }
        public string? ColumnName { get; set; }
        public string? ImageUrl { get; set; }   
    }
}