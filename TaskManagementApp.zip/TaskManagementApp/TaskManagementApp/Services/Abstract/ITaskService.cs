﻿using TaskManagementApp.Models;

namespace TaskManagementApp.Services.Abstract
{
    public interface ITaskService
    {
        IEnumerable<TaskItem> GetAllTasks();
        TaskItem? GetTask(int id);
        void AddTask(TaskItem task);
        bool EditTask(int id, TaskItem updatedTask);
        bool DeleteTask(int id);
        bool MoveTaskToColumn(int id, string newColumn);
    }
}
