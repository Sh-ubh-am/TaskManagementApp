﻿using TaskManagementApp.Models;
using TaskManagementApp.Services.Abstract;

namespace TaskManagementApp.Services.Concrete
{
    public class TaskService : ITaskService
    {
        private readonly List<TaskItem> _tasks;

        public TaskService()
        {
            _tasks = new List<TaskItem>();
        }

        public IEnumerable<TaskItem> GetAllTasks()
        {
            return _tasks;
        }

        public TaskItem? GetTask(int id)
        {
            return _tasks.FirstOrDefault(t => t.Id == id);
        }

        public void AddTask(TaskItem task)
        {
            if (task == null) throw new ArgumentNullException(nameof(task));
            task.Id = _tasks.Count > 0 ? _tasks.Max(t => t.Id) + 1 : 1;
            _tasks.Add(task);
        }

        public bool EditTask(int id, TaskItem updatedTask)
        {
            var existingTask = GetTask(id);
            if (existingTask == null)
                return false;

            existingTask.Name = updatedTask.Name;
            existingTask.Description = updatedTask.Description;
            existingTask.Deadline = updatedTask.Deadline;
            existingTask.ColumnName = updatedTask.ColumnName;
            return true;
        }

        public bool DeleteTask(int id)
        {
            var task = GetTask(id);
            if (task == null)
                return false;

            _tasks.Remove(task);
            return true;
        }

        public bool MoveTaskToColumn(int id, string newColumn)
        {
            var task = GetTask(id);
            if (task == null)
                return false;

            task.ColumnName = newColumn;
            return true;
        }
    }
}
