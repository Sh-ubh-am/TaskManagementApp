using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Text.Json;
using TaskManagementApp.Models;
using TaskManagementApp.Services.Abstract;

namespace TaskManagementApp.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class TasksController : ControllerBase
    {
        private readonly ITaskService _taskService;

        public TasksController(ITaskService taskService)
        {
            _taskService = taskService;
        }

        [HttpGet]
        public HttpResponseMessage GetAllTasks()
        {
            var tasks = _taskService.GetAllTasks();
            var serializedTasks = JsonSerializer.Serialize(tasks);

            return new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(serializedTasks, System.Text.Encoding.UTF8, "application/json")
            };
         }


        [HttpPost]
        public HttpResponseMessage AddTask(TaskItem task)
        {
            if (string.IsNullOrEmpty(task.Name))
            {
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
            }

            _taskService.AddTask(task);
            return new HttpResponseMessage(HttpStatusCode.OK);
        }

        [HttpPut("{id}")]
        public HttpResponseMessage EditTask(int id, TaskItem updatedTask)
        {
            var task = _taskService.GetTask(id);
            if (task == null)
            {
                return new HttpResponseMessage(HttpStatusCode.NotFound);
            }

            _taskService.EditTask(id, updatedTask);
            return new HttpResponseMessage(HttpStatusCode.OK);
        }

        [HttpDelete("{id}")]
        public HttpResponseMessage DeleteTask(int id)
        {
            var task = _taskService.GetTask(id);
            if (task == null)
            {
                return new HttpResponseMessage(HttpStatusCode.NotFound);
            }

            _taskService.DeleteTask(id);
            return new HttpResponseMessage(HttpStatusCode.OK);
        }

        [HttpGet("{id}")]
        public HttpResponseMessage GetTask(int id)
        {
            var task = _taskService.GetTask(id);
            if (task == null)
            {
                return new HttpResponseMessage(HttpStatusCode.NotFound);
            }

            return new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent($"Task Name: {task.Name}, Description: {task.Description}")
            };
        }

        [HttpPut("updateTaskColumn/{id}")]
        public HttpResponseMessage MoveTaskToColumn(int id, string column)
        {
            var task = _taskService.GetTask(id);
            if (task == null)
            {
                return new HttpResponseMessage(HttpStatusCode.NotFound);
            }

            _taskService.MoveTaskToColumn(id, column);
            return new HttpResponseMessage(HttpStatusCode.OK);
        }
        
    }
}